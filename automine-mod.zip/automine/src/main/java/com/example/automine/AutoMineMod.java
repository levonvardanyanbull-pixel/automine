package com.example.automine;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;

public class AutoMineMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoMiner::tick);

        // Return false = the message is cancelled and never reaches the server.
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> !DotCommands.handle(message));
    }
}
