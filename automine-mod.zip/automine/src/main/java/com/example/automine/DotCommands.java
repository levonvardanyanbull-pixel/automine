package com.example.automine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * Chat commands that start with a dot: .pos1 .pos2 .start .stop .status .fix <seconds> .help
 * Any chat message that starts with "." followed by a letter is swallowed locally and never sent to the server.
 */
public final class DotCommands {
    private DotCommands() {}

    /** @return true if the message was an AutoMine command and must NOT be sent to the server. */
    public static boolean handle(String raw) {
        String msg = raw.trim();
        if (!msg.matches("^\\.[A-Za-z].*")) return false;

        String[] parts = msg.substring(1).split("\\s+");
        String cmd = parts[0].toLowerCase();

        switch (cmd) {
            case "pos1" -> setPos(true);
            case "pos2" -> setPos(false);
            case "start" -> AutoMiner.say(AutoMiner.start());
            case "stop" -> AutoMiner.stop("Stopped.");
            case "status" -> AutoMiner.say(AutoMiner.status());
            case "fix" -> setFix(parts);
            case "help" -> AutoMiner.say(".pos1  .pos2  .start  .stop  .status  .fix <seconds, 0=off>");
            default -> AutoMiner.say("Unknown command '." + cmd + "'. Try .help");
        }
        return true;
    }

    /** Uses the block you're looking at, or your own feet position if you're not looking at one. */
    private static void setPos(boolean first) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        BlockPos p;
        if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            p = hit.getBlockPos();
        } else {
            p = mc.player.getBlockPos();
        }

        if (first) AutoMiner.pos1 = p; else AutoMiner.pos2 = p;
        AutoMiner.say("pos" + (first ? 1 : 2) + " set to " + p.toShortString());
    }

    private static void setFix(String[] parts) {
        if (parts.length < 2) {
            AutoMiner.say("Usage: .fix <seconds>  (0 turns it off). Currently: "
                    + (AutoMiner.fixIntervalSeconds == 0 ? "off" : AutoMiner.fixIntervalSeconds + "s"));
            return;
        }
        try {
            int s = Integer.parseInt(parts[1]);
            if (s < 0 || s > 3600) {
                AutoMiner.say("Pick a number between 0 and 3600.");
                return;
            }
            AutoMiner.fixIntervalSeconds = s;
            AutoMiner.say(s == 0 ? "/fix timer disabled." : "Will send /fix every " + s + "s while mining.");
        } catch (NumberFormatException e) {
            AutoMiner.say("'" + parts[1] + "' is not a number.");
        }
    }
}
