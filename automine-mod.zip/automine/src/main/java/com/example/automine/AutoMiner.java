package com.example.automine;

import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/**
 * Mines the selected area layer by layer (top to bottom), nearest block first.
 * It aims at the block, holds the attack key, and walks toward it if it's out of reach.
 * Because it uses the normal attack key, your 3x3 pickaxe behaves exactly as if you mined by hand.
 */
public final class AutoMiner {
    private AutoMiner() {}

    // ---- selection ----
    public static BlockPos pos1, pos2;
    private static int minX, minY, minZ, maxX, maxY, maxZ;

    // ---- settings ----
    public static int fixIntervalSeconds = 60; // 0 = off

    private static final double REACH = 4.0;
    private static final int STUCK_LIMIT_TICKS = 20 * 20; // give up on a block after 20s
    private static final float MIN_HEALTH = 6.0f;        // stop at 3 hearts

    // ---- state ----
    private static boolean active;
    private static int fixTimer;
    private static BlockPos target;
    private static int layerY;
    private static int stuckTicks;
    private static final Set<BlockPos> skipped = new HashSet<>();

    public static boolean isActive() {
        return active;
    }

    public static String start() {
        if (pos1 == null || pos2 == null) return "Set both corners first with .pos1 and .pos2.";
        minX = Math.min(pos1.getX(), pos2.getX());
        minY = Math.min(pos1.getY(), pos2.getY());
        minZ = Math.min(pos1.getZ(), pos2.getZ());
        maxX = Math.max(pos1.getX(), pos2.getX());
        maxY = Math.max(pos1.getY(), pos2.getY());
        maxZ = Math.max(pos1.getZ(), pos2.getZ());

        layerY = maxY;
        target = null;
        stuckTicks = 0;
        fixTimer = 0;
        skipped.clear();
        active = true;
        return "Started. Hold your 3x3 pickaxe. Stop with .stop (opening any menu also pauses it).";
    }

    public static void stop(String reason) {
        active = false;
        target = null;
        releaseKeys(MinecraftClient.getInstance());
        say(reason);
    }

    /** Prints a local-only chat line (never sent to the server). */
    public static void say(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("[AutoMine] " + msg), false);
        }
    }

    public static String status() {
        long vol = 0;
        if (pos1 != null && pos2 != null) {
            vol = (long) (Math.abs(pos1.getX() - pos2.getX()) + 1)
                    * (Math.abs(pos1.getY() - pos2.getY()) + 1)
                    * (Math.abs(pos1.getZ() - pos2.getZ()) + 1);
        }
        return "active=" + active
                + ", pos1=" + (pos1 == null ? "unset" : pos1.toShortString())
                + ", pos2=" + (pos2 == null ? "unset" : pos2.toShortString())
                + ", volume=" + vol
                + ", /fix every " + (fixIntervalSeconds == 0 ? "never" : fixIntervalSeconds + "s");
    }

    // ------------------------------------------------------------------

    public static void tick(MinecraftClient mc) {
        if (!active) return;

        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (player == null || world == null) {
            active = false; // disconnected
            return;
        }

        // Any open screen (chat, pause menu, inventory...) pauses everything = easy emergency stop.
        if (mc.currentScreen != null) {
            releaseKeys(mc);
            return;
        }

        if (player.getHealth() <= MIN_HEALTH) {
            stop("Stopped: low health.");
            return;
        }
        if (player.getMainHandStack().isEmpty()) {
            stop("Stopped: nothing in your main hand (did the pickaxe break?).");
            return;
        }

        // ---- /fix timer ----
        if (fixIntervalSeconds > 0 && ++fixTimer >= fixIntervalSeconds * 20) {
            fixTimer = 0;
            player.networkHandler.sendChatCommand("fix");
        }

        // ---- choose a target ----
        if (target == null || !isMineable(world, target)) {
            target = pickTarget(world, player);
            stuckTicks = 0;
            if (target == null) {
                stop("Done, the area is cleared.");
                return;
            }
        }
        if (++stuckTicks > STUCK_LIMIT_TICKS) {
            skipped.add(target);
            target = null;
            stuckTicks = 0;
            releaseKeys(mc);
            return;
        }

        // ---- aim ----
        Vec3d eye = player.getEyePos();
        Vec3d center = Vec3d.ofCenter(target);
        double dx = center.x - eye.x;
        double dy = center.y - eye.y;
        double dz = center.z - eye.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz > 1.0E-3) {
            player.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        player.setPitch((float) -Math.toDegrees(Math.atan2(dy, horiz)));

        // ---- walk closer if needed ----
        boolean tooFar = eye.distanceTo(center) > REACH;
        mc.options.forwardKey.setPressed(tooFar);
        mc.options.jumpKey.setPressed(tooFar && player.horizontalCollision);

        // ---- mine, but only if what's under the crosshair is inside the selection ----
        boolean attack = false;
        if (mc.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos hp = hit.getBlockPos();
            attack = inArea(hp) && isMineable(world, hp);
        }
        mc.options.attackKey.setPressed(attack);
    }

    // ------------------------------------------------------------------

    private static BlockPos pickTarget(ClientWorld world, ClientPlayerEntity player) {
        Vec3d eye = player.getEyePos();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (; layerY >= minY; layerY--) {
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    m.set(x, layerY, z);
                    if (!isMineable(world, m) || skipped.contains(m)) continue;
                    double d = eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (d < bestDist) {
                        bestDist = d;
                        best = m.toImmutable();
                    }
                }
            }
            if (best != null) return best;
        }
        return null;
    }

    private static boolean isMineable(ClientWorld world, BlockPos p) {
        BlockState s = world.getBlockState(p);
        return !s.isAir()
                && !(s.getBlock() instanceof FluidBlock)
                && s.getHardness(world, p) >= 0; // skips bedrock etc.
    }

    private static boolean inArea(BlockPos p) {
        return p.getX() >= minX && p.getX() <= maxX
                && p.getY() >= minY && p.getY() <= maxY
                && p.getZ() >= minZ && p.getZ() <= maxZ;
    }

    private static void releaseKeys(MinecraftClient mc) {
        if (mc.options == null) return;
        mc.options.attackKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }
}
